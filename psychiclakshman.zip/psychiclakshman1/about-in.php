<section style="background-color: #06263b; color: #fff; padding: 60px 20px;">
    <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; align-items: center; gap: 40px;">
        
        <!-- Text Column (LEFT) -->
        <div style="flex: 1 1 55%;">
            <h2 style="font-size: 38px; margin-bottom: 10px; color:#ff6a00 ">Know About Astrology</h2>
            <div style="width: 50px; height: 3px; background-color: #ff6a00; margin-bottom: 20px;"></div>
            <p style="line-height: 1.6; color:white; font-size:1.8rem;">
                Psychic Lakshman, based in New York, offers deep insights into the ancient science of astrology. He helps you understand how planetary positions affect your love life, career, health, and more through detailed birth chart analysis.
            </p>
            <p style="margin-top: 20px; line-height: 1.6;  color:white; font-size:1.8rem;">
                With years of experience and powerful spiritual wisdom, Psychic Lakshman provides accurate predictions and effective remedies. His trusted guidance helps you make the right decisions and align with your true path in life.
            </p>
            <a href="contact-us.php" style="display: inline-block; margin-top: 25px; background-color: #ff6a00; color: white; padding: 12px 25px; text-decoration: none; font-weight: bold; clip-path: polygon(10% 0%, 90% 0%, 100% 50%, 90% 100%, 10% 100%, 0% 50%);">
                CONSULT NOW
            </a>
        </div>

        <!-- Image Column (RIGHT) -->
        <div style="flex: 1 1 40%; position: relative;">
            <img src="./images/la.jpg" alt="Astrology Wheel" style="width: 100%; border: 10px solid #0b3b55; box-shadow: 0 0 20px rgba(0,0,0,0.4);" />
        </div>
    </div>

    <!-- Contact Box -->
    <div style="margin-top: 50px; max-width: 700px; background-color: #0b3b55; padding: 25px 30px; display: flex; align-items: center; gap: 20px; border-radius: 10px; margin-left: auto; margin-right: auto;">
        <div style="background-color: #ff6a00; border-radius: 50%; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
            <svg xmlns="http://www.w3.org/2000/svg" fill="white" width="30" height="30" viewBox="0 0 24 24">
                <path d="M21.707 16.293l-3-3a.999.999 0 00-1.414 0l-2 2a.999.999 0 01-1.414 0l-5-5a.999.999 0 010-1.414l2-2a.999.999 0 000-1.414l-3-3A.999.999 0 006.586 3l-2 2A3.974 3.974 0 003 7c0 9.374 7.626 17 17 17a3.974 3.974 0 002-1.586l2-2a.999.999 0 000-1.414z"/>
            </svg>
        </div>
        <div>
            <p style="margin: 0; font-size: 18px; color:white">Contact Our Expert Astrologers</p>
            <p style="margin: 5px 0 0; font-size: 24px; font-weight: bold; color: #ff6a00;">+1 (929) 635-1277</p>
        </div>
    </div>
</section>
<section class="stats-section">
  <div class="stats-container" id="stats">
    <div class="stat-box">
      <div class="stat-number" data-target="242" data-prefix="+">0</div>
      <div class="stat-label">Love Problems Solved</div>
    </div>
    <div class="stat-box">
      <div class="stat-number" data-target="400" data-prefix="+">0</div>
      <div class="stat-label">Happy Customers</div>
    </div>
    <div class="stat-box">
      <div class="stat-number" data-target="98" data-prefix="+">0</div>
      <div class="stat-label">Horoscopes</div>
    </div>
    <div class="stat-box">
      <div class="stat-number" data-target="67" data-prefix="+">0</div>
      <div class="stat-label">Published Books</div>
    </div>
  </div>
</section>

<style>
  .stats-section {
    background-color: #0b0c1a; /* Dark background */
    padding: 100px 20px;
    color: #fff;
	font-family:'math sans';
  }

  .stats-container {
    max-width: 1200px;
    margin: auto;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    text-align: center;
    opacity: 0;
    transform: translateY(40px);
    transition: all 1s ease-in-out;
  }

  .stats-container.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .stat-box {
    flex: 1 1 200px;
    margin: 30px 20px;
    background-color: #141627;
    padding: 30px 20px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
	 border: 2px solid #ff6a00;
  }

  .stat-number {
    font-size: 56px;
    font-weight: 700;
    color: #f2c47d;
    margin-bottom: 10px;
  }

  .stat-label {
    font-size: 18px;
    color: #d2d2d2;
    font-weight: 400;
  }

  @media (max-width: 768px) {
    .stat-box {
      flex: 1 1 100%;
    }
    .stat-number {
      font-size: 40px;
    }
  }
</style>

<script>
  function animateCounters() {
    const stats = document.querySelectorAll('.stat-number');
    stats.forEach(stat => {
      const target = +stat.getAttribute('data-target');
      const prefix = stat.getAttribute('data-prefix') || '';
      const updateCount = () => {
        const count = +stat.innerText.replace(/\D/g, '');
        const increment = target / 60;

        if (count < target) {
          stat.innerText = prefix + Math.ceil(count + increment);
          setTimeout(updateCount, 30);
        } else {
          stat.innerText = prefix + target;
        }
      };
      updateCount();
    });
  }

  window.addEventListener('scroll', () => {
    const statsSection = document.getElementById('stats');
    const sectionTop = statsSection.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;

    if (sectionTop < windowHeight - 100 && !statsSection.classList.contains('visible')) {
      statsSection.classList.add('visible');
      animateCounters();
    }
  });
</script>


