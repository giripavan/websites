<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	<section class="spiritual-protection-section" style="padding: 80px 0; background: linear-gradient(to bottom, #0a0a2e 0%, #1b0b4b 100%); position: relative; overflow: hidden;">
  <!-- Protective Energy Symbols -->
  <div class="symbols" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="symbol" style="position: absolute; color: rgba(255,223,0,0.4); font-size: 24px; animation: float 14s linear infinite;">🛡️</div>
    <div class="symbol" style="position: absolute; left: 20%; top: 10%; color: rgba(138,43,226,0.5); font-size: 28px; animation: float 18s linear infinite reverse;">🔮</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="protection-content" style="background: rgba(20,10,50,0.9); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #8a2be2; box-shadow: 0 10px 30px rgba(0,0,0,0.4);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #8a2be2; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">SPIRITUAL SHIELDING</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Black Magic Removal
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #8a2be2, transparent);"></span>
            </h2>
          </div>
          
          <div class="cleansing-guidance" style="color: #d8bfd8; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(138,43,226,0.4);color:white;">
              Negative energies manifest in many forms. Renowned spiritual healer Lakshman specializes in identifying and eliminating:
            </p>
            
            <div class="purification-note" style="background: rgba(138,43,226,0.15); border-left: 4px solid #8a2be2; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #b19cd9; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">⚔️</span> Break Dark Energy Attacks
                </h4>
                <p style="margin-bottom: 0; color: #e6e6fa; font-size: 1.75rem;">
                    Unexplained misfortunes, sudden illnesses, or recurring nightmares may indicate spiritual attacks. Lakshman's ancient Vedic protection rituals create an impenetrable aura shield.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(138,43,226,0.4);color:white;">
              Using sacred mantras (Mritunjaya, Mahamrityunjaya) and yantra energy grids, Lakshman has successfully removed black magic for 1,500+ clients with permanent results verified through pranic scans.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss6.jpg" 
               alt="Spiritual Cleansing Ritual" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.4; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
    .purification-note:hover {
      background: rgba(138,43,226,0.25) !important;
      transform: translateY(-3px);
      transition: all 0.3s ease;
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	