<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	<section class="business-astrology-section" style="padding: 80px 0; background: linear-gradient(to bottom, #0a1a2e 0%, #0b3d4b 100%); position: relative; overflow: hidden;">
  <!-- Floating Diamond Particles -->
  <div class="diamonds" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="diamond" style="position: absolute; color: rgba(0,191,255,0.3); font-size: 20px; animation: float 15s linear infinite;">◆</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="business-astrology-content" style="background: rgba(10,30,50,0.8); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #00bfff; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #00bfff; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">BUSINESS SOLUTIONS</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Corporate Astrology Guidance
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #00bfff, transparent);"></span>
            </h2>
          </div>
          
          <div class="business-content" style="color: #c6e2ff; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(0,191,255,0.3);color:white;">
              Business challenges often have unseen cosmic influences. Renowned corporate astrologer Lakshman provides strategic celestial insights to help enterprises navigate:
            </p>
            
            <div class="success-note" style="background: rgba(0,100,255,0.1); border-left: 4px solid #0064ff; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #6ba8ff; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">📈</span> Transform Business Challenges
                </h4>
                <p style="margin-bottom: 0; color: #b8d8ff; font-size: 1.75rem;">
                    Financial obstacles, partnership conflicts, or stalled growth can be overcome. Business Psychic Lakshman reveals auspicious timing and strategic remedies for success.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(0,191,255,0.3);color:white;">
              Combining ancient Vedic techniques with modern business acumen, Lakshman's corporate astrology services have helped Fortune 500 companies and startups alike optimize their financial destiny and leadership potential.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss4.jpg" 
               alt="Corporate Astrology" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.3; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	