<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="keywords" content="">
    <title>Black-magic-remover</title>
	<?php
	include('header.php');
	?>
	<!-- service indicator banner -->
	
    	<div class="auto-container">
       
        </div>
    </section>
<section class="cosmic-contact-section" style="padding: 60px 0; background: url('https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D&w=1000&q=80') no-repeat center center/cover; position: relative;">
    <!-- Cosmic Overlay -->
    <div style="position: absolute; top:0; left:0; width:100%; height:100%; background: #F4631E; z-index: 0;"></div>
    
    <div class="container-fluid" style="position: relative; z-index: 1;">
        <div class="container">
            <div class="row">
                <!-- Contact Form Column -->
                <div class="col-md-6 col-sm-12">
                    <div class="cosmic-contact-box" style="background: rgba(15, 14, 23, 0.9); border-radius: 15px; padding: 40px; border: 1px solid #6c63ff; box-shadow: 0 0 30px rgba(110, 99, 255, 0.3);">
                        <h2 style="color: #eebbc3; font-size: 2.8rem; margin-bottom: 30px; text-align: center; position: relative;">
                            <span style="background: linear-gradient(45deg, yellow, yellow); -webkit-background-clip: text; background-clip: text; color: transparent;">Channel Cosmic Guidance</span>
                            <div style="position: absolute; bottom: -15px; left: 50%; transform: translateX(-50%); width: 80px; height: 3px; background: linear-gradient(90deg, transparent, #6c63ff, transparent);"></div>
                        </h2>
                        
                        <form id="astrologyContactForm" style="margin-top: 30px;">
                            <div class="form-group" style="margin-bottom: 25px;">
                                <label for="name" style="color: #eebbc3; margin-bottom: 8px; display: block;">Your Name</label>
                                <input type="text" class="form-control" id="name"  style="background: rgba(255,255,255,0.1); border: 1px solid #6c63ff; color: white; padding: 12px 15px; border-radius: 8px; width: 100%;">
                                
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 25px;">
                                <label for="birthdate" style="color: #eebbc3; margin-bottom: 8px; display: block;">Birth Date</label>
                                <input type="date" class="form-control" id="birthdate" style="background: rgba(255,255,255,0.1); border: 1px solid #6c63ff; color: white; padding: 12px 15px; border-radius: 8px; width: 100%;">
                            </div>
                            
                            
                            <div class="form-group" style="margin-bottom: 25px;">
                                <label for="question" style="color: #eebbc3; margin-bottom: 8px; display: block;">Your Cosmic Question</label>
                                <textarea class="form-control" id="question" rows="4" placeholder="Ask about love, career, or destiny..." style="background: rgba(255,255,255,0.1); border: 1px solid #6c63ff; color: white; padding: 12px 15px; border-radius: 8px; width: 100%; resize: none;"></textarea>
                            </div>
                            
                        
                            
                            <div class="form-group" style="margin-bottom: 25px;">
                                <label for="contactInfo" style="color: #eebbc3; margin-bottom: 8px; display: block;">Email/Phone</label>
                                <input type="text" class="form-control" id="contactInfo" placeholder="Where should we send your reading?" style="background: rgba(255,255,255,0.1); border: 1px solid #6c63ff; color: white; padding: 12px 15px; border-radius: 8px; width: 100%;">
                            </div>
                            
                            <button type="submit" style="background: linear-gradient(45deg, #9d4edd, #6c63ff); border: none; color: white; padding: 15px 30px; border-radius: 50px; font-size: 1.5rem; cursor: pointer; width: 100%; transition: all 0.3s; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; display: flex; align-items: center; justify-content: center; gap: 10px;">
                                <i class="fas fa-star" style="font-size: 0.9rem;"></i> 
                                Request Cosmic Guidance
                                <i class="fas fa-arrow-right" style="font-size: 0.9rem;"></i>
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Contact Info Column -->
                <div class="col-md-5 col-sm-12 offset-md-1" style="margin-top: 30px;">
                    <div style="margin-bottom: 40px;">
                        <h3 style="color:  #183B4E; font-size: 3rem; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-globe-americas" style="color: #183B4E;"></i>
                            <span>Psychic Lakshman</span>
                        </h3>
                        <p style="color: black ; line-height: 1.8; margin-bottom: 25px; font-size: 1.75rem">
                            For personalized astrological guidance, spiritual consultations, or emergency readings, connect through these celestial channels:
                        </p>
                        
                        <div style="background: #183B4E; border-left: 3px solid #6c63ff; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                            <h4 style="color: yellow; margin-bottom: 10px; font-size: 1.8rem;">
                                <i class="fas fa-map-marker-alt" style="margin-right: 10px; color: #6c63ff;"></i>
                                New York Cosmic Center
                            </h4>
                            <p style="color: rgb(255, 255, 255); margin: 0; font-size: 1.75rem">
                                115-11 Liberty Ave, South Richmond  <br>
                                Hill, NY 11419, United States.
                            </p>
                        </div>
                        
                        <div style="background: #183B4E; border-left: 3px solid #6c63ff; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                            <h4 style="color: yellow; margin-bottom: 10px; font-size: 1.8rem;">
                                <i class="fas fa-phone-alt" style="margin-right: 10px; color: #6c63ff;"></i>
                                Celestial Hotline
                            </h4>
                            <p style="color: rgb(255, 255, 255); margin: 0; font-size: 1.75rem">
                                +1 (929) 635-1277<br>
                                <small style="color: #6c63ff;">Available 10AM-8PM EST</small>
                            </p>
                        </div>
                        
                        <div style="background: #183B4E; border-left: 3px solid #6c63ff; padding: 15px; margin-bottom: 25px; border-radius: 0 8px 8px 0;">
                            <h4 style="color: yellow; margin-bottom: 10px; font-size: 1.8rem;">
                                <i class="fas fa-envelope" style="margin-right: 10px; color: #6c63ff;"></i>
                                Cosmic Mail
                            </h4>
                            <p style="color: rgb(255, 255, 255); margin: 0; font-size: 1.75rem">
                                master.laxman07@gmail.com<br>
                                <small style="color: #6c63ff;">Response within 24 hours</small>
                            </p>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating cosmic elements -->
    <div class="floating-cosmic" style="position: absolute; top: 20%; left: 10%; font-size: 2rem; color: rgba(110, 99, 255, 0.5); z-index: 0; animation: float 15s infinite ease-in-out;">♄</div>
    <div class="floating-cosmic" style="position: absolute; top: 60%; right: 15%; font-size: 1.5rem; color: rgba(238, 187, 195, 0.5); z-index: 0; animation: float 12s infinite ease-in-out reverse;">☽</div>
    <div class="floating-cosmic" style="position: absolute; bottom: 10%; left: 50%; font-size: 3rem; color: rgba(255, 158, 0, 0.3); z-index: 0; animation: float 20s infinite ease-in-out;">☉</div>
</section>

<style>
    @keyframes float {
        0%, 100% { transform: translateY(0) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(5deg); }
    }
    
    .cosmic-contact-box input:focus, 
    .cosmic-contact-box select:focus, 
    .cosmic-contact-box textarea:focus {
        background: rgba(255,255,255,0.15) !important;
        border-color: #eebbc3 !important;
        box-shadow: 0 0 10px rgba(238, 187, 195, 0.5) !important;
        outline: none;
    }
    
    button[type="submit"]:hover {
        background: linear-gradient(45deg, #6c63ff, #9d4edd) !important;
        transform: translateY(-3px);
        box-shadow: 0 10px 20px rgba(110, 99, 255, 0.4);
    }
</style>

<script>
    // Simple form validation
    document.getElementById('astrologyContactForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const question = document.getElementById('question').value;
        
        if(!name || !question) {
            alert('Please fill in your name and cosmic question');
            return;
        }
        
        // Here you would typically send the form data to your server
        alert('Your cosmic request has been sent to the stars! Hanuman Ji will contact you soon.');
        this.reset();
    });
</script>
	<?php
	include('footer.php');
	?>
	
	
	