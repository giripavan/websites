<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	<section class="couple-disputes-section" style="padding: 80px 0; background: linear-gradient(to bottom, #2e0a1a 0%, #4b0b2b 100%); position: relative; overflow: hidden;">
  <!-- Floating Reconciliation Symbols -->
  <div class="symbols" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="symbol" style="position: absolute; color: rgba(255,215,0,0.3); font-size: 22px; animation: float 14s linear infinite;">⚖️</div>
    <div class="symbol" style="position: absolute; left: 25%; top: 15%; color: rgba(255,105,180,0.4); font-size: 26px; animation: float 16s linear infinite reverse;">🤝</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="dispute-content" style="background: rgba(50,10,30,0.8); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #ffd700; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #ffd700; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">RELATIONSHIP HARMONY</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Couple Dispute Resolution
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #ffd700, transparent);"></span>
            </h2>
          </div>
          
          <div class="resolution-content" style="color: #ffd1dc; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,215,0,0.3);color:white;">
              Every relationship faces storms. Astrologer Lakshman specializes in celestial conflict mediation to help couples overcome:
            </p>
            
            <div class="reconciliation-note" style="background: rgba(255,215,0,0.1); border-left: 4px solid #ffd700; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #ffdf80; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">💑</span> Restore Your Bond
                </h4>
                <p style="margin-bottom: 0; color: #ffe5b8; font-size: 1.75rem;">
                    Communication breakdowns, trust issues, or intimacy gaps - Lakshman's astrological remedies create harmonious energy flow between partners.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,215,0,0.3);color:white;">
              Using Venus-Mars alignment analysis and past life karmic readings, Lakshman has successfully mediated 85% of couple disputes, transforming arguments into deeper understanding.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss2.jpg" 
               alt="Corporate Astrology" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.3; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
    .reconciliation-note:hover {
      background: rgba(255,215,0,0.15) !important;
      transform: translateY(-3px);
      transition: all 0.3s ease;
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	