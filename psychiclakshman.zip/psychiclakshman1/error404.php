<?php
include('header.php');
?>
<section style="padding:50px 0px">
    
    <h4 style="text-align:center;color:#ff0000;font-family: 'Oswald', sans-serif;">Hmm, the page not found</h4>
    
    <center><a href="https://www.psychiclakshman.com/"style="color:#ffffff;padding:10px;background:#ff0000;box-shadow:0px 0px 9px #000">Back to home</a></center>
</section>
<?php
include('footer.php');
?>