<!-- footer start -->

<div id="footer">

	<div class="container">
		<div class="row">
		
			<div class="footer-box-section">
			
		
				
						<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color:yellow;">about us </h6>
				<p style="color:white;">
				 Some people, out of jealousy or ill intent, use black magic to disrupt the lives of others. While magic can take many forms, it’s often divided into two main types: white magic and black magic. Both are powerful, but black magic is used with harmful intentions. Its effects can be severe, especially when performed by those who truly master the dark arts.
				</p>
				</div>
				
				
				<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color:yellow;">Psychic Services </h6>
					
					<ul>
						<li><a href="love-astrologer.php">Love Astrologer</a></li>
                            <li><a href="couple-disputes.php">Couple disputes</a></li>
                            <li><a href="love-marriage.php">Love marriage</a></li>
                            <li><a href="business-problem.php">Business problem</a></li>
                            <li><a href="health-problem.php">Health problem</a></li>
                            <li><a href="black-magic.php">Black magic</a></li>
                            <li><a href="negative-energy.php">Negitive energy</a></li>
                            <li><a href="vashikaran-special.php">Vashikaran special</a></li>
					</ul>
					
				</div>
						<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color:yellow;">Quick Links </h6>
					
					<ul>
						<li> <a href="index.php">Home </a> </li>
						<li> <a href="about-us.php">About Psychic </a> </li>
					
						<li> <a href="contact-us.php">Contact Us </a> </li>
					</ul>
					
					
			
				</div>
				
		
				
				<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color:yellow;" >Contact Us </h6>
					
					<div class="foot-contact">
                    	<img src="images/footer-address-icon.png" alt="footer address">
                        <p><span> Address: </span> 
							 <?php echo $address ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-email-icon.png" alt="email-address">
                        <p><span> Email Support:</span> 
							<?php echo $email ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-phone-icons.png" alt="phone address">
                        <p><span> Phone No: </span>
							<a href="tel:<?php echo $linkphone ?>"style="color:#ffffff"> 
								<?php echo $phone ?>
							</a>
							<br>
						</p>
                    </div>
					
				</div>
			
			
			</div>
			
			
			
		</div>
	</div>
</div>


<section id="disclaimer">
    <div class="container-fluid">
        <div class="disclaimer">
            <p><b>Disclaimer:</b> Individual results may differ based on personal circumstances and other influencing factors.</p>

			<span style="color:white;">
		The astrology consultations and services provided by Psychic Lakshman are based on his knowledge of astrology and your unique situation. While efforts are made to offer accurate insights, there is no guarantee regarding the outcome. Psychic Lakshman cannot be held liable for any consequences arising from the use of his services.

			</span>       </div>
    </div>
</section>
<!-- footer end -->
</body>	
	 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<!-- slider js -->
	<script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">jssor_1_slider_init();</script>
	<!-- End slider js -->
    <!-- Bootsnavs -->
    <script src="js/bootsnav.js"></script>
	<!-- Testimonial js -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items:
			3,
			itemsDesktop:[1199,2],
			itemsDesktopSmall:[980,2],
			itemsMobile:[600,1],
			pagination:false,
			navigationText:false,
			autoPlay:true
		});
	});
	</script>
	<script>
	$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:3,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
});
</script>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
</html>