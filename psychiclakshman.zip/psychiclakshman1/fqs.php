	
<section style="padding: 80px 0; background: linear-gradient(135deg, #faf6f0 0%, #f1e8d8 100%);">
  <div class="container" style="max-width: 1100px; margin: 0 auto; padding: 0 20px;">
    <div class="section-header" style="text-align: center; margin-bottom: 50px;">
      <h2 style="font-size: 3.2rem; color: #5d4037; margin-bottom: 15px; font-weight: 700; letter-spacing: -0.5px;">Frequently Asked Questions</h2>
      <p style="color: #8d6e63; font-size: 1.5rem; max-width: 600px; margin: 0 auto; line-height: 1.6;">Find answers about our spiritual guidance services</p>
      <div style="width: 80px; height: 4px; background: #d4af37; margin: 20px auto; border-radius: 2px;"></div>
    </div>

    <div class="faq-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 25px;">
      
      <!-- FAQ Item 1 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q1</span>
          </div>
          <h3 style="font-size: 2.2rem; color: #5d4037; margin: 0; font-weight: 600;">How do astrologers help?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">Astrologers provide insights through birth chart analysis, helping with relationships, life decisions, emotional well-being, and career guidance.</p>
        </div>
      </div>

      <!-- FAQ Item 2 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q2</span>
          </div>
          <h3 style="font-size: 2.2rem; color: #5d4037; margin: 0; font-weight: 600;">How astrology works in human life?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">Celestial positions at birth influence personality and life events through planetary alignments and their energetic impacts.</p>
        </div>
      </div>

      <!-- FAQ Item 3 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q3</span>
          </div>
          <h3 style="font-size: 2.2rem; color: #5d4037; margin: 0; font-weight: 600;">Can astrology predict marriage?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">Yes, by analyzing planetary positions, dashas, and transits in your birth chart, particularly focusing on Jupiter's influence.</p>
        </div>
      </div>

      <!-- FAQ Item 4 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q4</span>
          </div>
          <h3 style="font-size: 2.0rem; color: #5d4037; margin: 0; font-weight: 600;">How does astrology predict marriage timing?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">Through examination of dasha periods, planetary transits, and specific marriage yogas in the birth chart.</p>
        </div>
      </div>

      <!-- FAQ Item 5 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q5</span>
          </div>
          <h3 style="font-size: 2.2rem; color: #5d4037; margin: 0; font-weight: 600;">How accurate are Psychic Lakshman's readings?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">With 20+ years experience and 5,000+ satisfied clients, Psychic Lakshman's readings are highly accurate and insightful.</p>
        </div>
      </div>

      <!-- FAQ Item 6 -->
      <div class="faq-card" style="background: white; border-radius: 12px; padding: 25px; box-shadow: 0 5px 15px rgba(93, 64, 55, 0.05); border-left: 4px solid #d4af37;">
        <div class="faq-header" style="display: flex; align-items: center; margin-bottom: 15px;">
          <div style="width: 40px; height: 40px; background: #fff8e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
            <span style="color: #d4af37; font-size: 1.2rem; font-weight: 700;">Q6</span>
          </div>
          <h3 style="font-size: 2rem; color: #5d4037; margin: 0; font-weight: 600;">Is Psychic Lakshman's service accurate in New York?</h3>
        </div>
        <div class="faq-content" style="padding-left: 55px;">
          <p style="color: #8d6e63; line-height: 1.75; margin: 0; font-size:1.75rem;">Absolutely, with numerous satisfied clients in New York benefiting from his accurate readings and spiritual guidance.</p>
        </div>
      </div>

    </div>

    
  </div>
</section>