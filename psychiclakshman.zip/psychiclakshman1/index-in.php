<section class="psychic-sanju-section" style="background: #4E1F00; padding: 80px 0; color: white;">
    <div class="container">
        <div class="row">
           
            
            <!-- Content Column -->
            <div class="col-lg-7 order-lg-1 order-2 mt-lg-0">
                <div style="background: rgba(255,255,255,0.05); border-radius: 15px; padding: 30px; border: 1px solid rgba(255,215,0,0.2);">
                    <div class="d-flex align-items-center mb-4">
                        <div style="width: 50px; height: 3px; background: linear-gradient(to right, #FFD700, #FFA500); margin-right: 20px;"></div>
                        <h2 style="color: #FFD700; margin: 0; font-weight: 700; letter-spacing: 1px;">PSYCHIC LAKSHMAN</h2>
                    </div>
                    
                    <h1 style="font-size: 38px; font-weight: 700; margin-bottom: 25px; line-height: 1.3;color:white;">
                        The <span style="color: #FFD700;">Most Trusted</span> Astrologer in New York
                    </h1>
                    
                    <div style="margin-bottom: 30px; padding: 20px; background: rgba(0,0,0,0.3); border-left: 3px solid #FFD700;">
                        <p style="text-align: justify; line-height: 1.8; font-size: 18px; margin: 0; color:white;">
                            Psychic Lakshman is a renowned astrologer based in New York, known for his deep insight and spiritual wisdom. Coming from a lineage of gifted astrologers, he began his journey early in life. His powerful guidance and accurate readings have earned him international recognition and a devoted global clientele.
                        </p>
                    </div>
                    
                    <!-- Services Cards with Perfect Mobile Spacing -->
                    <div class="service-boxes-container">
                        <div class="service-box" style="background: rgba(255,215,0,0.1); border-radius: 10px; padding: 25px; margin-bottom: 25px; border: 1px solid rgba(255,215,0,0.2);">
                            <div style="width: 50px; height: 50px; background: #FFD700; color: #000; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; font-weight: bold; font-size: 20px;">1</div>
                            <h3 style="color: #FFD700; font-size: 22px; margin-bottom: 12px;">Remove Bad Luck</h3>
                            <p style="font-size: 16px; line-height: 1.6; margin-bottom: 15px; color:white;">Expert in clearing black magic and negative energies—fast results within 48 hours.</p>
                            
                        </div>
                        
                        <div class="service-box" style="background: rgba(255,215,0,0.1); border-radius: 10px; padding: 25px; margin-bottom: 25px; border: 1px solid rgba(255,215,0,0.2);">
                            <div style="width: 50px; height: 50px; background: #FFD700; color: #000; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; font-weight: bold; font-size: 20px;">2</div>
                            <h3 style="color: #FFD700; font-size: 22px; margin-bottom: 12px;">Love Solutions</h3>
                            <p style="font-size: 16px; line-height: 1.6; margin-bottom: 15px;  color:white;">Reunite with your lost love in 9 days using powerful and trusted astrological solutions.</p>
                            
                        </div>
                        
                        <div class="service-box" style="background: rgba(255,215,0,0.1); border-radius: 10px; padding: 25px; border: 1px solid rgba(255,215,0,0.2);">
                            <div style="width: 50px; height: 50px; background: #FFD700; color: #000; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; font-weight: bold; font-size: 20px;">3</div>
                            <h3 style="color: #FFD700; font-size: 22px; margin-bottom: 12px;">Relationship Healing</h3>
                            <p style="font-size: 16px; line-height: 1.6; margin-bottom: 15px;  color:white;">Win back their heart without desperation—spiritual methods that truly work.</p>
                            <a href="contact-us.php" style="color: #FFD700; font-size: 13px; text-decoration: none; display: inline-block;">Contact now →</a>
                        </div>
                    </div>
                </div>
            </div>

<br>
			 <!-- Image Column - Centered on Mobile -->
			 <div class="col-lg-5 order-lg-2 order-1 mb-5 mb-lg-0 d-flex justify-content-center">
                <div style="width: 100%; max-width: 350px; position: relative;">
                    <img src="./images/lm.jpg" alt="Psychic Sanju" class="img-fluid" style="border-radius: 10px; box-shadow: 0 25px 50px rgba(0,0,0,0.5); border: 5px solid rgba(255,215,0,0.3);">
                    <div style="position: absolute; bottom: -20px; left: 100px; background: #FFD700; color: #000; padding: 10px 25px; border-radius: 5px; font-weight: 700; box-shadow: 0 10px 20px rgba(0,0,0,0.3); font-size:1.4rem;">
                        No. 1 Astrologer in New York
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    /* Mobile-specific adjustments */
    @media (max-width: 767px) {
        .psychic-sanju-section {
            padding: 60px 0 !important;
        }
        
        /* Perfect spacing between service boxes */
        .service-box {
            margin-bottom: 30px !important; /* Increased gap to 30px */
        }
        
        /* Remove margin from last box */
        .service-box:last-child {
            margin-bottom: 0 !important;
        }
        
        /* Center image with proper spacing */
        .col-lg-5.order-lg-2.order-1 {
            margin-bottom: 40px !important;
            padding: 0 15px;
			max-width: 290px;
        }
        
        /* Content adjustments */
        .psychic-sanju-section h1 {
            font-size: 28px !important;
            text-align: center;
        }
        
        /* Divider alignment */
        .d-flex.align-items-center.mb-4 {
            justify-content: center;
        }
        
        /* Padding adjustments */
        .col-lg-7 > div {
            padding: 25px !important;
        }
    }

    /* Desktop styling for boxes */
    @media (min-width: 768px) {
        .service-boxes-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        .service-box {
            margin-bottom: 0 !important;
        }
    }
</style>