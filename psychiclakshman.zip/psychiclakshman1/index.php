<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
<!-- Event snippet for Submit lead form conversion page -->


	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
   <title>Astrologer in New York</title>
    
    <?php
	include('header.php');
	?>
	
 <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:510px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="../svg/loading/static-svg/spin.svg" alt="Astrologer in " />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:510px;overflow:hidden;">
           
<div>
                <img data-u="image" src="./images/lbn1.jpg" alt="Palm Reading"/>
            </div>
		   <div>
                <img data-u="image" src="./images/lbn2.jpg" alt="Get Love Back"/>
            </div>
            <div>
                <img data-u="image" src="./images/lbn3.jpg" alt="Black Magic Removal"/>
            </div>
            
		
     
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb053" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <path class="b" d="M11400,13800H4600c-1320,0-2400-1080-2400-2400V4600c0-1320,1080-2400,2400-2400h6800 c1320,0,2400,1080,2400,2400v6800C13800,12720,12720,13800,11400,13800z"></path>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora093" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="7777.8,6080 5857.8,8000 7777.8,9920 "></polyline>
                <line class="a" x1="10142.2" y1="8000" x2="5857.8" y2="8000"></line>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora093" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="8222.2,6080 10142.2,8000 8222.2,9920 "></polyline>
                <line class="a" x1="5857.8" y1="8000" x2="10142.2" y2="8000"></line>
            </svg>
        </div>
    </div>
	<!-- about section start -->

	
	<?php
	include('index-in.php');
	?>
	
	
	<?php
	include('services.php');
	?>
	

		
	<?php
	include('fqs.php');
	?>
	
	
	<?php
	include('testimonials.php');
	?>
	
	
	
    <?php
	include('pooja-services.php');
	?>
	
	
	
	
		<section class="psychic-profile" style="background: url('https://images.unsplash.com/photo-1531685250784-7569952593d2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80') no-repeat center center; background-size: cover; padding: 80px 0; position: relative;">
    <!-- Dark overlay for readability -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background:#7D0A0A;"></div>
    
    <div class="container" style="position: relative; z-index: 2;">
        <div class="row align-items-center">
            <!-- Image Column (Left) -->
            <div class="col-md-5 text-center mb-4 mb-md-0">
                <div style="border: 3px solid #b886fc; border-radius: 50%; padding: 10px; display: inline-block;">
                    <img src="./images/lb.png" alt="Psychic Lakshman" style="width: 280px; height: 280px; object-fit: cover; border-radius: 50%; border: 5px solid #4a0072;">
                </div>
                <h3 class="mt-3" style="color:yellow; font-family: 'Georgia', serif;">Psychic Lakshman</h3>
                <p style="color: White; letter-spacing: 2px; font-size: 14px;">BLACKMAGIC REMOVAL SPECIALIST</p>
            </div>
            
            <!-- Content Column (Right) -->
            <div class="col-md-7">
                <div style="background: rgba(42, 8, 70, 0.7); backdrop-filter: blur(5px); border-radius: 15px; padding: 30px; border-left: 4px solid #b886fc;">
                    <div style="color: yellow; font-size: 14px; letter-spacing: 3px; margin-bottom: 10px;">20 YEARS OF WISDOM</div>
                    <h1 style="color: #fff; font-size: 2.8rem; margin-bottom: 25px; font-family: 'Playfair Display', serif;">Spiritual Solutions for Modern Problems</h1>
                    
                    <!-- Expertise 1 -->
                    <div style="margin-bottom: 25px;">
                        <h3 style="color: yellow; border-bottom: 1px dashed #b886fc; padding-bottom: 8px; display: inline-block; font-size:3rem;">Blackmagic Removal</h3>
                        <p style="color:white; line-height: 1.8; font-size:1.75rem;">
                            Psychic Lakshman is a renowned astrologer in New York with extraordinary skills in astrology. Born into an astrological lineage, he began his practice young and has helped countless clients with his profound knowledge.
                        </p>
                    </div>
                    
                    <!-- Expertise 2 -->
                    <div style="margin-bottom: 30px;">
                        <h3 style="color: yellow; border-bottom: 1px dashed #b886fc; padding-bottom: 8px; display: inline-block; font-size:3rem;">Love Reconciliation</h3>
                        <p style="color:white; line-height: 1.8; font-size:1.75rem;">
                            As a <strong>Negative Energy Removal Specialist</strong> in New York, Psychic Lakshman provides solutions for life's challenges, whether you're seeking love, prosperity, or spiritual cleansing.
                        </p>
                    </div>
                    
                    <a href="contact-us.php" style="display: inline-block; background: linear-gradient(90deg, #8a2be2, #4a0072); color: white; padding: 12px 30px; border-radius: 8px; text-decoration: none; font-weight: 600; letter-spacing: 1px; transition: all 0.3s; border: 1px solid #b886fc;">
                        ✨ Book Spiritual Consultation
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
	<div class="clearfix"></div>
	
	


	
	<?php
	include('footer.php');
	?>