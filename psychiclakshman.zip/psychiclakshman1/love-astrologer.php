<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	
	<section class="love-astrology-section" style="padding: 80px 0; background: linear-gradient(to bottom, #1a0a2e 0%, #3d0b4b 100%); position: relative; overflow: hidden;">
  <!-- Floating Heart Particles -->
  <div class="hearts" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="heart" style="position: absolute; color: rgba(255,105,180,0.3); font-size: 20px; animation: float 15s linear infinite;">❤</div>
    <div class="heart" style="position: absolute; left: 20%; top: 30%; color: rgba(255,182,193,0.4); font-size: 28px; animation: float 18s linear infinite reverse;">♥</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="love-astrology-content" style="background: rgba(30,10,50,0.8); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #ff69b4; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #ff69b4; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">SOULMATE CONNECTION</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Love Astrology Guidance
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #ff69b4, transparent);"></span>
            </h2>
          </div>
          
          <div class="love-content" style="color: #e2c6ff; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,105,180,0.3);color:white;">
              The stars reveal your romantic destiny. World-renowned love astrologer Lakshman decodes celestial messages to help you navigate:
            </p>
            
            <div class="love-note" style="background: rgba(255,20,147,0.1); border-left: 4px solid #ff1493; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #ff6bcf; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">🌹</span> Discover Your Love Blueprint
                </h4>
                <p style="margin-bottom: 0; color: #ffb8e9; font-size: 1.75rem;">
                    Whether seeking love or strengthening a bond, Lakshman's cosmic insights reveal compatibility, timing, and soulmate connections written in the stars.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,105,180,0.3);color:white;">
              Through Vedic synastry and Venus transit analysis, Lakshman has guided thousands in New York to manifest loving relationships and heal heartbreak with celestial wisdom.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss1.jpg" 
               alt="Corporate Astrology" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.3; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
    .love-note:hover {
      background: rgba(255,20,147,0.15) !important;
      transform: translateY(-3px);
      transition: all 0.3s ease;
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	