<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	<section class="love-marriage-section" style="padding: 80px 0; background: linear-gradient(to bottom, #1a0a3d 0%, #3d0b4b 100%); position: relative; overflow: hidden;">
  <!-- Floating Celestial Symbols -->
  <div class="symbols" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="symbol" style="position: absolute; color: rgba(255,215,0,0.4); font-size: 24px; animation: float 18s linear infinite;">💫</div>
    <div class="symbol" style="position: absolute; left: 30%; top: 20%; color: rgba(230,230,250,0.5); font-size: 28px; animation: float 15s linear infinite reverse;">🌠</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="marriage-content" style="background: rgba(40,10,60,0.85); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #9370db; box-shadow: 0 10px 30px rgba(0,0,0,0.4);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #9370db; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">DESTINED UNION</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Love Marriage Astrology
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #9370db, transparent);"></span>
            </h2>
          </div>
          
          <div class="marriage-guidance" style="color: #e6e6fa; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(147,112,219,0.4);color:white;">
              Your celestial marriage blueprint awaits. Master astrologer Lakshman reveals the cosmic timing and compatibility factors for destined unions:
            </p>
            
            <div class="destiny-note" style="background: rgba(147,112,219,0.15); border-left: 4px solid #9370db; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #b19cd9; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">👰‍♂️</span> Manifest Your Sacred Union
                </h4>
                <p style="margin-bottom: 0; color: #d8bfd8; font-size: 1.75rem;">
                    Overcoming family resistance, cultural barriers, or karmic blocks - Lakshman's 7-step love marriage rituals align the stars for your holy matrimony.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(147,112,219,0.4);color:white;">
              Through specialized techniques like Nakshatra compatibility analysis and Mangal Dosha remedies, Lakshman has successfully guided 1,200+ love marriages with 92% long-term harmony rate.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss3.jpg" 
               alt="Corporate Astrology" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.4; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
    .destiny-note:hover {
      background: rgba(147,112,219,0.2) !important;
      transform: translateY(-3px);
      transition: all 0.3s ease;
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	