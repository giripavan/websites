<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	<section class="energy-clearing-section" style="padding: 80px 0; background: linear-gradient(to bottom, #1a0033 0%, #330066 100%); position: relative; overflow: hidden;">
  <!-- Cleansing Energy Symbols -->
  <div class="symbols" style="position: absolute; width: 100%; height: 100%; pointer-events: none;">
    <div class="symbol" style="position: absolute; color: rgba(255,255,0,0.4); font-size: 24px; animation: float 14s linear infinite;">🌀</div>
    <div class="symbol" style="position: absolute; left: 20%; top: 10%; color: rgba(255,0,255,0.3); font-size: 28px; animation: float 18s linear infinite reverse;">⚡</div>
  </div>

  <div class="container" style="position: relative; z-index: 2;">
    <div class="row align-items-center">
      <!-- Content Column -->
      <div class="col-lg-8 col-md-7 mb-5 mb-md-0">
        <div class="clearing-content" style="background: rgba(40,0,80,0.9); backdrop-filter: blur(8px); border-radius: 20px; padding: 40px; border-left: 4px solid #ff00ff; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
          <div class="section-header" style="margin-bottom: 30px;">
            <div class="section-tag" style="color: #ff00ff; font-size: 16px; letter-spacing: 3px; margin-bottom: 10px;">ENERGY PURIFICATION</div>
            <h2 style="color: white; font-size: 3.2rem; margin: 0; font-family: 'Playfair Display', serif; position: relative; display: inline-block;">
              Negative Energy Removal
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #ff00ff, transparent);"></span>
            </h2>
          </div>
          
          <div class="purification-guidance" style="color: #f0d8ff; line-height: 1.8; font-size: 1.75rem;">
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,0,255,0.4);color:white;">
              Stagnant or hostile energies can disrupt your life. Master energy healer Lakshman specializes in detecting and eliminating:
            </p>
            
            <div class="cleansing-note" style="background: rgba(255,0,255,0.15); border-left: 4px solid #ff00ff; padding: 15px; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
                <h4 style="color: #ff77ff; margin-top: 0; display: flex; align-items: center; font-size: 2.2rem;">
                    <span style="margin-right: 10px;">🧿</span> Break Toxic Energy Attachments
                </h4>
                <p style="margin-bottom: 0; color: #ffbbff; font-size: 1.75rem;">
                    Unexplained fatigue, sudden mood swings, or recurring bad luck often signal negative energy attachments. Lakshman's 7-layer aura cleansing restores your natural energetic flow.
                </p>
            </div>
            
            <p style="margin-bottom: 25px; position: relative; padding-left: 20px; border-left: 2px solid rgba(255,0,255,0.4);color:white;">
              Using ancient Vedic space clearing (Agni Hotra) combined with Tibetan sound bowl therapy, Lakshman has cleared negative energy for 3,000+ clients with 94% reporting immediate relief.
            </p>
          </div>
        </div>
      </div>
      <br>
      <!-- Image Column -->
      <div class="col-lg-4 col-md-5">
        <div style="height: 100%; display: flex; align-items: center; justify-content: center; padding: 0;">
          <img src="./images/lss7.jpg" 
               alt="Energy Cleansing Ritual" 
               style="width: 100%; height: auto; max-height: 700px; object-fit: cover; border-radius: 15px; box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4); border: 4px solid rgb(243, 239, 8); transition: transform 0.3s ease;"
               onmouseover="this.style.transform='scale(1.02)'"
               onmouseout="this.style.transform='scale(1)'">
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      10% { opacity: 0.4; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
    .cleansing-note:hover {
      background: rgba(255,0,255,0.25) !important;
      transform: translateY(-3px);
      transition: all 0.3s ease;
    }
  </style>
</section>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('fqs.php');
	?>
	<?php
	include('footer.php');
	?>
	
	