<section class="sacred-pooja-section">
    <!-- Divine Pattern Background -->
    <div class="divine-pattern"></div>
    
    <div class="container">
        <!-- Section Header with Sacred Symbol -->
        <div class="section-intro">
            <div class="sacred-symbol">
                <svg viewBox="0 0 100 100">
                    <path d="M50,10 L60,40 L90,50 L60,60 L50,90 L40,60 L10,50 L40,40 Z" fill="none" stroke="#e67e22" stroke-width="2"/>
                    <circle cx="50" cy="50" r="15" fill="none" stroke="#e67e22" stroke-width="2"/>
                </svg>
            </div>
            <h2 style="font-size:2.8rem;">Sacred Pooja <span>Services</span></h2>
            <p style="font-size:1.5rem; color:black;">Vedic rituals to align your stars and remove obstacles</p>
        </div>

        <!-- Pooja Services Grid -->
        <div class="pooja-grid">
            <!-- Service 1 - Kali Maa Pooja -->
            <div class="pooja-card featured">
                <div class="card-image">
                    <img src="./images/lpp1.jpg" alt="Kali Maa Pooja">
                    <div class="image-tags">
                        <span class="tag">Power</span>
                        <span class="tag">Protection</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card-meta">
                        <span class="duration"><i class="fas fa-clock"></i> 2.5 Hours</span>
                        
                    </div>
                    <h3>Kali Maa Pooja</h3>
                    <p class="card-desc">Psychic Lakshman performs powerful rituals to invoke Goddess Kali for protection strength and removal of negative energies bringing peace and spiritual power to your life.</p>
                    <div class="card-footer">
                        <a href="#" class="btn-ritual">Book Ritual</a>
                        
                    </div>
                </div>
                <div class="card-aura"></div>
            </div>

            <!-- Service 2 - Hanuman Pooja -->
            <div class="pooja-card featured">
                <div class="card-image">
                    <img src="./images/lpp2.jpg" alt="Hanuman Pooja">
                    <div class="image-tags">
                        <span class="tag">Strength</span>
                        <span class="tag">Courage</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card-meta">
                        <span class="duration"><i class="fas fa-clock"></i> 2 Hours</span>
                        
                    </div>
                    <h3>Hanuman Pooja</h3>
                    <p class="card-desc">Psychic Lakshman invokes Lord Hanumans blessings to bring strength courage and protection from evil forces and harmful planetary effects for a safer and stronger life.</p>
                    <div class="card-footer">
                        <a href="#" class="btn-ritual">Book Ritual</a>
                       
                    </div>
                </div>
                <div class="card-aura"></div>
            </div>

            <!-- Service 3 - Ganesh Pooja -->
            <div class="pooja-card featured">
                <div class="card-image">
                    <img src="./images/lp3.jpg" alt="Ganesh Pooja">
                    <div class="image-tags">
                        <span class="tag">Wisdom</span>
                        <span class="tag">Success</span>
                    </div>
                </div>
                <div class="card-body">
					<div class="card-meta">
                        <span class="duration"><i class="fas fa-clock"></i> 2 Hours</span>
                        
                    </div>
                    
                    <h3>Ganesh Pooja</h3>
                    <p class="card-desc">Psychic Lakshman invokes Lord Ganeshas blessings to remove obstacles and bring success wisdom and good fortune in all areas of life through powerful spiritual rituals.</p>
                    <div class="card-footer">
                        <a href="#" class="btn-ritual">Book Ritual</a>
                        
                    </div>
                </div>
                <div class="card-aura"></div>
            </div>

                
        </div>        
    </div>
</section>

<style>
/* Base Styles */
.sacred-pooja-section {
    position: relative;
    background: #f9f5f0;
    padding: 80px 0;
    font-family: 'Poppins', sans-serif;
    overflow: hidden;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    position: relative;
    z-index: 2;
}

/* Divine Pattern Background */
.divine-pattern {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(rgba(230, 126, 34, 0.1) 2px, transparent 2px);
    background-size: 30px 30px;
    opacity: 0.6;
    z-index: 1;
}

/* Section Header */
.section-intro {
    text-align: center;
    margin-bottom: 60px;
    position: relative;
}

.sacred-symbol {
    width: 80px;
    height: 80px;
    margin: 0 auto 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: float 6s ease-in-out infinite;
}

.sacred-symbol svg {
    width: 60px;
    height: 60px;
}

@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

.section-intro h2 {
    font-size: 3rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 10px;
}

.section-intro h2 span {
    font-weight: 300;
    color: #e67e22;
	font-size:3rem;
}

.section-intro p {
    color: #7f8c8d;
    font-size: 1.1rem;
    max-width: 600px;
    margin: 0 auto;
}

/* Pooja Grid */
.pooja-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 30px;
    margin-bottom: 50px;
}

.pooja-card {
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    position: relative;
}

.pooja-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.pooja-card.featured {
    border: 2px solid #e67e22;
}

.featured-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: #e67e22;
    color: #fff;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    z-index: 3;
}

/* Card Image */
.card-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.card-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.pooja-card:hover .card-image img {
    transform: scale(1.05);
}

.image-tags {
    position: absolute;
    bottom: 15px;
    left: 15px;
    display: flex;
    gap: 8px;
}

.image-tags .tag {
    background: rgba(0, 0, 0, 0.7);
    color: #fff;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 1.15rem;
    font-weight: 500;
    backdrop-filter: blur(5px);
}

/* Card Body */
.card-body {
    padding: 20px;
}

.card-meta {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    font-size: 1.2rem;
    color: black;
}

.card-meta .duration {
    display: flex;
    align-items: center;
}

.card-meta .duration i {
    margin-right: 5px;
    color: #e67e22;
}

.card-meta .price {
    font-weight: 600;
    color: #2c3e50;
}

.card-body h3 {
    font-size: 2.4rem;
    color: #e67e22;
    margin-bottom: 10px;
    font-weight: 600;
}

.card-desc {
    color: black;
    font-size: 1.74rem;
    line-height: 1.6;
    margin-bottom: 20px;
}

/* Card Footer */
.card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.btn-ritual {
    background: #e67e22;
    color: #fff;
    padding: 8px 20px;
    border-radius: 6px;
    font-size: 1.6rem;
    font-weight: 500;
    transition: all 0.3s ease;
    text-decoration: none;
    flex: 1;
    margin-right: 10px;
    text-align: center;
}

.btn-ritual:hover {
    background: #d35400;
}

.btn-learn {
    color: #3498db;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.3s ease;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.btn-learn:hover {
    color: #2980b9;
}

.btn-learn i {
    margin-left: 5px;
    font-size: 0.8rem;
}

/* Card Aura Effect */
.card-aura {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle at center, rgba(230, 126, 34, 0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: -1;
}

.pooja-card:hover .card-aura {
    opacity: 1;
}

/* View All CTA */
.view-all-cta {
    text-align: center;
}

.btn-view-all {
    display: inline-flex;
    align-items: center;
    background: #2c3e50;
    color: #fff;
    padding: 12px 25px;
    border-radius: 30px;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.3s ease;
}

.btn-view-all:hover {
    background: #1a252f;
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.btn-view-all svg {
    margin-left: 10px;
    width: 18px;
    height: 18px;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .section-intro h2 {
        font-size: 2rem;
    }
    
    .pooja-grid {
        grid-template-columns: 1fr;
    }
    
    .card-footer {
        flex-direction: column;
    }
    
    .btn-ritual {
        width: 100%;
        margin-right: 0;
        margin-bottom: 10px;
    }
    
    .btn-learn {
        width: 100%;
        justify-content: center;
    }
}

/* Font Import */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
</style>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	
	
	