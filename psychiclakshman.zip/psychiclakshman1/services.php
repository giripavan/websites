<section class="spiritual-services" style="padding: 80px 0; background: linear-gradient(to bottom, #f8f9ff, #e8f4fe);">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        <div class="section-header" style="text-align: center; margin-bottom: 60px;">
            
            <h2 style="font-size: 3rem; color: #2d3748; margin-bottom: 15px; font-weight: 700; line-height: 1.2; transform: translateY(0); transition: all 0.3s ease;">
                Transform Your Life With<br>Ancient Wisdom
            </h2>
            <p style="color: black; font-size: 1.5rem; max-width: 700px; margin: 0 auto; line-height: 1.6; transform: translateY(0); transition: all 0.3s ease;">
                Expert spiritual guidance tailored to your unique situation with Psychic Lakshman
            </p>
        </div>

        <div class="services-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;">
            <!-- Service 1 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls1.jpg" alt="Palmistry" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #667eea, #764ba2);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Palm Reading</h3>
                        <span style="width: 40px; height: 40px; background: #ebf4ff; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-hand-paper" style="color: #5e72e4; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color: black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman provides accurate palm readings that uncover your past present and future Offering insights into love career health and life path through the ancient art of palmistry.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(102,126,234,0.1) 0%, rgba(118,75,162,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>

            <!-- Service 2 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls2.jpg" alt="Love Back" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #f687b3, #d53f8c);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Love Reconciliation</h3>
                        <span style="width: 40px; height: 40px; background: #fff5f7; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-heart" style="color: #e53e3e; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color: black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman specializes in love reconciliation helping you reunite with your partner and restore lost connections using powerful and trusted spiritual methods that truly work.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(246,135,179,0.1) 0%, rgba(213,63,140,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>

            <!-- Service 3 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls3.jpg" alt="Astrology" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #f6ad55, #dd6b20);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Vedic Astrology</h3>
                        <span style="width: 40px; height: 40px; background: #fffaf0; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-star" style="color: #dd6b20; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color: black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman offers deep insights through Vedic Astrology guiding you in health and life decisions with accurate predictions based on ancient and powerful astrological wisdom.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(246,173,85,0.1) 0%, rgba(221,107,32,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>

            <!-- Service 4 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls4.jpg" alt="Energy Cleansing" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #68d391, #38a169);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Energy Cleansing</h3>
                        <span style="width: 40px; height: 40px; background: #f0fff4; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-bolt" style="color: #38a169; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color: black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman offers energy cleansing to remove negative energy clear spiritual blockages and restore balance peace and positivity using ancient powerful and trusted spiritual methods.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(104,211,145,0.1) 0%, rgba(56,161,105,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>

            <!-- Service 5 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls5.jpg" alt="Spiritual Protection" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #805ad5, #6b46c1);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Spiritual Protection</h3>
                        <span style="width: 40px; height: 40px; background: #faf5ff; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-shield-alt" style="color: #6b46c1; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color: black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman provides strong spiritual protection to shield you from evil eye black magic and negative forces ensuring safety peace and positive energy with powerful ancient techniques.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(128,90,213,0.1) 0%, rgba(107,70,193,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>

            <!-- Service 6 -->
            <div class="service-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; position: relative;">
                <div class="service-image" style="height: 200px; overflow: hidden; position: relative;">
                    <img src="./images/ls6.jpg" alt="Family Harmony" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                    <div style="position: absolute; bottom: 0; left: 0; right: 0; height: 4px; background: linear-gradient(to right, #4299e1, #3182ce);"></div>
                </div>
                <div class="service-content" style="padding: 25px; position: relative; z-index: 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="color: #2d3748; margin: 0; font-size: 2.4rem; font-weight: 700; transition: all 0.3s ease;">Family Problems</h3>
                        <span style="width: 40px; height: 40px; background: #ebf8ff; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                            <i class="fas fa-home" style="color: #3182ce; font-size: 2.2rem; transition: all 0.3s ease;"></i>
                        </span>
                    </div>
                    <p style="color:black; margin-bottom: 20px; line-height: 1.6; font-size: 1.75rem; transition: all 0.3s ease;">
                        Psychic Lakshman helps resolve family problems by restoring harmony understanding and peace using powerful spiritual solutions and ancient methods to heal relationships and remove negativity.
                    </p>
                    <div class="service-actions" style="display: flex; gap: 10px;">
                        <a href="tel:+1 (929) 635-1277" style="flex: 1; background: #5e72e4; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fas fa-phone-alt" style="margin-right: 8px;"></i> Call Now
                        </a>
                        <a href="https://wa.me/19296351277" style="flex: 1; background: #48bb78; color: white; text-align: center; padding: 12px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; transform: translateY(0);">
                            <i class="fab fa-whatsapp" style="margin-right: 8px;"></i> WhatsApp
                        </a>
                    </div>
                </div>
                <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(66,153,225,0.1) 0%, rgba(49,130,206,0.1) 100%); opacity: 0; transition: all 0.3s ease; z-index: 1;"></div>
            </div>
        </div>

        
    </div>
</section>

<!-- Font Awesome for proper icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>
    /* Hover Animations */
    .service-card:hover {
        transform: translateY(-5px) !important;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1) !important;
    }
    
    .service-card:hover .service-image img {
        transform: scale(1.1) !important;
    }
    
    .service-card:hover h3 {
        color: #5e72e4 !important;
    }
    
    .service-card:hover .service-content > div > span {
        transform: rotate(15deg) scale(1.1) !important;
        background: #5e72e4 !important;
    }
    
    .service-card:hover .service-content > div > span i {
        color: white !important;
    }
    
    .service-card:hover .service-actions a {
        transform: translateY(-3px) !important;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
    }
    
    .service-card:hover .service-actions a:first-child {
        background: #4a60d1 !important;
    }
    
    .service-card:hover .service-actions a:last-child {
        background: #3ea56d !important;
    }
    
    .service-card:hover > div:last-child {
        opacity: 1 !important;
    }
    
    /* Header hover effects */
    .section-header:hover span {
        transform: translateY(-3px) !important;
        box-shadow: 0 5px 15px rgba(94,114,228,0.3) !important;
    }
    
    .section-header:hover h2 {
        transform: translateY(-2px) !important;
    }
    
    .section-header:hover p {
        transform: translateY(-1px) !important;
    }
    
    /* View All button hover */
    .view-all a:hover {
        background: #5e72e4 !important;
        color: white !important;
        transform: translateY(-3px) !important;
        box-shadow: 0 10px 20px rgba(94,114,228,0.2) !important;
    }
    
    .view-all a:hover i {
        transform: translateX(5px) !important;
    }
</style>