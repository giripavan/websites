<!-- testimonials start -->
<section style="padding: 40px; background: #f0f0f0;">
  <div style="
    max-width: 1200px;
    margin: 0 auto;
    background: white;
    border: 4px solid #004aad; /* Border color */
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  ">
    
    <div style="padding: 24px; background-color: #004aad; color: white;">
      <h2 style="margin: 0; font-size: 2.4rem; text-align: center; color:white;"> 📍Our Location</h2>
    </div>
    
    <div style="width: 100%; height: 500px;">
      <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3021.6107052363144!2d-73.8224987240106!3d40.68805034450367!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c261f2c8a7d267%3A0xf7964e80145f6d83!2s115-11%20Liberty%20Ave%2C%20South%20Richmond%20Hill%2C%20NY%2011419%2C%20USA!5e0!3m2!1sen!2sus!4v1715713963655!5m2!1sen!2sus" 
        width="100%" 
        height="100%" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">
      </iframe>

    </div>
  </div>
</section>

<section style="padding: 80px 0; background-color: #f9f5ff;">
  <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    
    <!-- Section Header -->
    <div style="text-align: center; margin-bottom: 60px;">
      <h2 style="font-size: 3rem; color: #4a1d96; margin-bottom: 15px; font-weight: 700;">Client Experiences</h2>
      <p style="color: #6b46c1; font-size: 1.5rem; max-width: 600px; margin: 0 auto;">
        Real stories from people whose lives we've touched
      </p>
    </div>

    <!-- Testimonials Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">

      <!-- Testimonial 1 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt1.jpg" alt="Andries" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Andries</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">New York</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
         I was facing career uncertainty and financial struggles Psychic Lakshman’s advice gave me the clarity and direction I needed to grow professionally and financially His guidance truly changed my life.
        </p>
      </div>

      <!-- Testimonial 2 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt2.jpg" alt="Amelia" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Amelia</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">California</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
          I felt overwhelmed by negative energy Psychic Lakshman performed cleansing rituals that cleared my mind and space Now I feel a sense of calm and positivity every day Thank you for your help.
        </p>
      </div>

      <!-- Testimonial 3 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt3.jpg" alt="Steven" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Steven</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">USA</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
          Psychic Lakshman’s spiritual insights helped me improve my health I followed his advice and felt a significant shift in my energy and overall well-being His guidance was truly transformative.
        </p>
      </div>

      <!-- Testimonial 4 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt4.jpg" alt="Laura" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Laura</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">Texas</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
          Psychic Lakshman helped me bring back my lost love His spiritual advice and remedies healed our relationship and brought us closer than ever I highly recommend his services for love-related issues.
        </p>
      </div>
          

      <!-- Testimonial 5 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt5.jpg" alt="Alex" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Alex</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">New York</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
          Our marriage was in trouble, but Psychic Lakshman’s astrological remedies and guidance turned everything around His support and advice brought peace and love back into our marriage We are so happy.
        </p>
      </div>


      <!-- Testimonial 6 -->
      <div style="background: white; border-radius: 16px; padding: 30px; box-shadow: 0 10px 30px rgba(74, 29, 150, 0.08); position: relative; border-top: 4px solid #9f7aea;">
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 3px solid #e9d8fd;">
            <img src="./images/lt6.jpg" alt="Charlotte" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <div>
            <h3 style="color: #2d3748; margin: 0; font-size: 2.2rem; font-weight: 700;">Charlotte</h3>
            <div style="display: flex; align-items: center; margin-top: 5px;">
              <span style="color: #6b46c1; font-size: 1.5rem;">New Jersey</span>
              <img src="images/google_review.jpg" style="width: 100px; margin-left: 15px;">
            </div>
          </div>
        </div>
        <p style="color: black; line-height: 1.7; font-size: 1.75rem; position: relative; padding-left: 25px;">
          <span style="position: absolute; left: 0; top: 0; color: #d6bcfa; font-size: 2rem; line-height: 1;">"</span>
          Psychic Lakshman provided me with strong spiritual protection against negative forces I now feel safe and at peace in my life His methods are effective and I highly recommend his services to all.
        </p>
      </div>
    </div>

    

  </div>
</section>
<!-- testimonials end -->